/// @file
#pragma once
#include <stdint.h>

void TCodes(char * const strchr_pointer, uint8_t codeValue);
